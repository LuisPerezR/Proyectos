/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arreglos;

import java.util.Scanner;

/**
 *
 * @author LuisPerez
 */
public class Arreglos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
        System.out.println("ingresa los numeros enteros"
                + "");
        Scanner sc = new Scanner(System.in);
        int[]arreglo= new int[20];
         
        arreglo[0]= sc.nextInt();
        arreglo[1]= sc.nextInt();
        arreglo[2]= sc.nextInt();
        arreglo[3]= sc.nextInt();
        arreglo[4]= sc.nextInt();
        arreglo[5]= sc.nextInt();
        arreglo[6]= sc.nextInt();
        arreglo[7]= sc.nextInt();
        arreglo[8]= sc.nextInt();
        arreglo[9]= sc.nextInt();
        arreglo[10]= sc.nextInt();
        arreglo[11]= sc.nextInt();
        arreglo[12]= sc.nextInt();
        arreglo[13]= sc.nextInt();
        arreglo[14]= sc.nextInt();
        arreglo[15]= sc.nextInt();
        arreglo[16]= sc.nextInt();
        arreglo[17]= sc.nextInt();
        arreglo[18]= sc.nextInt();
        arreglo[19]= sc.nextInt();
       
         System.out.println(" el arreglo es: ");
         for(int i=0; i<arreglo.length;i++){
             System.out.println(arreglo [i]+"");
    }
    }
    
}
