/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sumapar_inpar;

/**
 *
 * @author LuisPerez
 */
public class ParImpar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int p= 0;
        int c =0;
        for(int i= 0 ;i<=6;i++){
        
            if(i%2==0){
            p+=i;
           
                
            }else{
               c+=i; 
            }
            System.out.println("la suma de los tres primeros numeros pares es:"+p);
            System.out.println("la suma de los tres primeros numeros impares es:"+c);
        }
        
    }
}
     

    

